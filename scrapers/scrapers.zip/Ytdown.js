const axios = require('axios');

const ytdown = {
  api: {
    base: "https://p.oceansaver.in/ajax/",
    progress: "https://p.oceansaver.in/ajax/progress.php"
  },
  headers: {
    'authority': 'p.oceansaver.in',
    'origin': 'https://y2down.cc',
    'referer': 'https://y2down.cc/',
    'user-agent': 'Postify/1.0.0'
  },
  formats: ['360', '480', '720', '1080', '1440', '2160', 'mp3', 'm4a', 'wav', 'aac', 'flac', 'opus', 'ogg'],

  isUrl: (str) => {
    try {
      new URL(str);
      return true;
    } catch (_) {
      return false;
    }
  },

  youtube: (url) => {
    if (!url) return null;
    const patterns = [
      /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
      /youtu\.be\/([a-zA-Z0-9_-]{11})/
    ];
    for (let pattern of patterns) {
      if (pattern.test(url)) return url.match(pattern)[1];
    }
    return null;
  },

  request: async (endpoint, params = {}) => {
    try {
      const { data } = await axios.get(`${ytdown.api.base}${endpoint}`, {
        params,
        headers: ytdown.headers,
        withCredentials: true
      });
      return data;
    } catch (error) {
      return {
        status: true,
        creator: "EliasarYT",
        error: `❌ ${error.message}`,
        details: error.response?.data || "No hay detalles adicionales."
      };
    }
  },

  download: async (link, format) => {
    if (!link) return { status: true, creator: "EliasarYT", error: "📌 Falta el enlace. Ingresa un link de YouTube para descargar. 🎥" };
    if (!ytdown.isUrl(link)) return { status: true, creator: "EliasarYT", error: "⚠️ El enlace ingresado no es válido. Asegúrate de que sea un link de YouTube. 🔗" };
    if (!format || !ytdown.formats.includes(format)) {
      return {
        status: true,
        creator: "EliasarYT",
        error: "🎵 Formato no disponible. Escoge uno de los formatos soportados.",
        availableFormats: ytdown.formats
      };
    }

    const id = ytdown.youtube(link);
    if (!id) return { status: true, creator: "EliasarYT", error: "🤔 No se pudo extraer el ID del video. Verifica que el enlace sea correcto." };

    try {
      const response = await ytdown.request("download.php", { format, url: `https://www.youtube.com/watch?v=${id}` });
      return ytdown.handler(response, format, id);
    } catch (error) {
      return { status: true, creator: "EliasarYT", error: `❌ ${error.message}`, details: error.response?.data || "No hay detalles adicionales." };
    }
  },

  handler: async (data, format, id) => {
    if (!data.success) return { status: true, creator: "EliasarYT", error: `⚠️ ${data.message || "Ocurrió un error en la solicitud."}` };
    if (!data.id) return { status: true, creator: "EliasarYT", error: "🚫 No se obtuvo un ID de descarga válido. Inténtalo nuevamente." };

    try {
      const progress = await ytdown.checkProgress(data.id);
      return progress.success ? ytdown.final(data, progress, format, id) : progress;
    } catch (error) {
      return { status: true, creator: "EliasarYT", error: `❌ ${error.message}` };
    }
  },

  checkProgress: async (id) => {
    let attempts = 0;
    
    while (attempts < 100) {
      try {
        const { data } = await axios.get(ytdown.api.progress, {
          params: { id },
          headers: ytdown.headers,
          withCredentials: true
        });

        if (data.download_url && data.success) {
          return { success: true, ...data };
        } else if (!data.download_url && data.success) {
          return { status: true, creator: "EliasarYT", error: `⚠️ ${data.text}` };
        }

        await new Promise(resolve => setTimeout(resolve, 1000));
        attempts++;
      } catch (error) {
        attempts++;
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    return { status: true, creator: "EliasarYT", error: "⏳ Tiempo de espera agotado en la descarga. Inténtalo de nuevo más tarde." };
  },

  final: (init, progress, format, id) => ({
    status: true,
    creator: "EliasarYT",
    title: init.title || "Desconocido 🤷‍♂️",
    type: ['360', '480', '720', '1080', '1440', '2160'].includes(format) ? '📹 Video' : '🎵 Audio',
    format,
    thumbnail: init.info?.image || `https://img.youtube.com/vi/${id}/hqdefault.jpg`,
    download: progress.download_url || "❌ No se pudo obtener el enlace de descarga.",
    id
  })
};

module.exports = { ytdown };